import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";
import router from "@/router";
import { Store } from "vuex";

Vue.use(Vuex);

const REST_API = `http://localhost:9999`;

export default new Vuex.Store({
  state: {
    user: {},
    users: [],
    loginUser: null,
    facility: {},
    facilities: [],
  },
  getters: {
    // 운동시설 검색해서 반환
    facilities(state) {
      return state.facilities;
    },
    //운동시설 상세 조회 반환
    facility(state) {
      return state.facility;
    },
    // 운동시설 이용내역 한 개 반환
    facVisit(state) {
      return state.facVisit;
    },
    // 운동시설 이용내역 여러 개 반환
    facVisits(state) {
      return state.facVisits;
    },
  },
  mutations: {
    DO_REGIST(state, user) {
      state.user = user;
    },
    DO_LOGIN(state, user) {
      state.loginUser = user;
      localStorage.setItem("loginUser", JSON.stringify(user));
    },
    LOGOUT: function (state) {
      state.loginUser = null;
      localStorage.removeItem("loginUser");
    },
    GET_FACILITIES(state, payload) {
      state.facilities = payload;
    },
    GET_FACILITY(state, payload) {
      state.facility = payload;
    },
    USE_THISFAC(state, payload) {
      state.facility = payload;
    },
  },
  actions: {
    createRegist({ commit }, user) {
      const API_URL = `${REST_API}/gyudok-user/regist`;
      axios({
        url: API_URL,
        method: "POST",
        params: user,
      })
        .then(() => {
          commit("DO_REGIST", user);
          alert("등록되었습니다.");
          router.push("/");
        })
        .catch((err) => {
          alert("다시 작성해주세요.");
          console.log(err);
        });
    },
    setLoginUser({ commit }, user) {
      const API_URL = `${REST_API}/gyudok-user/login`;
      axios({
        url: API_URL,
        method: "POST",
        params: user,
      })
        .then((res) => {
          commit("DO_LOGIN", res.data);
          alert("로그인하였습니다.");
          router.push("/");
        })
        .catch((err) => {
          alert("비밀번호를 다시 입력해주세요.");
          console.log(err);
        });
    },
    getFacilities({ commit }, keyword) {
      // console.log(keyword);
      const API_URL = `${REST_API}/gyudok-subs/facsubs/search/${keyword}`;
      axios({
        url: API_URL,
        method: "GET",
        // params : keyword,
      })
        .then((res) => {
          console.log(res);
          commit("GET_FACILITIES", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getFacility({ commit }, id) {
      console.log("여기");
      const API_URL = `${REST_API}/gyudok-subs/facility/${id}`;
      axios({
        url: API_URL,
        method: "GET",
      })
        .then((res) => {
          console.log(res);
          commit("GET_FACILITY", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    useThisFac({ commit }, id) {
      let user_id = Store.state.loginUser.id;
      router.push;
      console.log(user_id);
      const API_URL = `${REST_API}/gyudok-subs/facility/${user_id}/${id}`;
      axios({
        url: API_URL,
        method: "POST",
        params: {
          user_id,
          id,
        },
      })
        .then(() => {
          commit("USE_THISFAC", this.params);
          alert("예약되었습니다 (전.이용하기)");
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
  modules: {},
});

// alert("등록되었습니다.");
// router.push("/");
// })
// .catch((err) => {
// alert("다시 작성해주세요.");
// console.log(err);
// });
