<template>
  <div>
    <WriteForm type="create"></WriteForm>
  </div>
</template>

<script>
import WriteForm from "../board/include/WriteForm.vue";

export default {
  name: "BoardCreate",
  components: {
    WriteForm,
  },
};
</script>

<style></style>
