<template>
  <div class="footer">
    <hr />
    <span style="font-size: 0.8em; text-align: left">
      9th SSAFY GYUHO and EUN</span>
    <!-- <h1>Footer</h1> -->
    <hr />
  </div>
</template>
<style scoped>
.footer {
  text-align: center;
  background-color: white;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  text-align: center;
}
</style>