<template>
  <div>
    <h2>규독페이지에 오신걸 환영합니다.</h2>
  </div>
</template>
