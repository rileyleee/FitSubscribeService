<template>
  <div id="app">
    <h2>커뮤니티껍데기</h2>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
};
</script>
