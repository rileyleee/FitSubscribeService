<template>
  <div>
    <h2>운동구독</h2>
    <b-container fluid="xl">
      <br />
      <router-view />
    </b-container>
  </div>
</template>

<script>
export default {
  name: "FacSubView",
};
</script>

<style scoped>
h2{
margin-left: 175px
}</style>
