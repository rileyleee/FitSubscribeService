<template>
  <hello-gyudok></hello-gyudok>
</template>

<script>
import HelloGyudok from "@/components/HelloGyudok.vue";
export default {
  name: "MainIntroView",

  components: {
    HelloGyudok,
  },
};
</script>
