package com.bodyguard.gyudok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GyuDokApplication {

	public static void main(String[] args) {
		SpringApplication.run(GyuDokApplication.class, args);
	}

}
